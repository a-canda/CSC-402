public class Gate {
    
}

class Input {
    
}

class Output {
    
}

class Wire {
    
}